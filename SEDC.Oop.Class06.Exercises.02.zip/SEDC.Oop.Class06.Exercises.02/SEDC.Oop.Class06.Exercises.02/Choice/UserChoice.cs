﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.Oop.Class06.Exercises._02.Choice
{
    public class UserChoice
    {

    }
}


bool flag = true;

while (true)
{
    Console.WriteLine("Enter your choice of whether you want to: 1. Enter the menu; 2: Login; 3: Register");

}