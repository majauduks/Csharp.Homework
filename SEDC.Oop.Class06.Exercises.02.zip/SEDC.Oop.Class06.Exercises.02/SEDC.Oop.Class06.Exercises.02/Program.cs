﻿using SEDC.Oop.Class06.Exercises._02.RegisteredUsers;
using System;

namespace SEDC.Oop.Class06.Exercises._02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Users[] usersArray = new Users[3];

           
        }
    }
}
