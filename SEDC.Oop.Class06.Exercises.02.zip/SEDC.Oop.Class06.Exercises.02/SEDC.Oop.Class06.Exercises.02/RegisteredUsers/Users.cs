﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.Oop.Class06.Exercises._02.RegisteredUsers
{
    public class Users
    {

        public string Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string[] StringArray { get; set; }



        public void LogIn(string username, string password)
        {
            Username = username;
            Password = password;
        }

        public void ReturnMessages(Users[] userExists, string username, string password)
        {
            foreach (Users user in userExists)
            {
                if (user.Username == Username && password == user.Password)
                {
                    Console.WriteLine($"Welcome {user.Username}, here are you messages:");
                    Console.WriteLine("Today is a beautiful day"); ;
                    Console.WriteLine("Try using it!");

                }

                else
                {
                    Console.WriteLine("There is no such user :( ");
                }
            }


        } public string[] Register(string username, int id, string password)
        {
            foreach (Users user in StringArray)
            {
                if (user.Username == Username)
                {
                    
                }

            }
        }

    
