﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.Oop.GuessTheNumber.Guessing
{
    public class Modes
    {
        public string GameType { get; set; }

        public Modes (string type)
        {
            GameType = type;
        }


        public void Easy ()
        {
            int triesNumber = 9;
            int maxTries = triesNumber;
            int range = 100;
            int randomNum = new Random().Next(0, range);
            int rangeMultiplication = 1;
            Game(GameType, triesNumber, range, randomNum, rangeMultiplication, maxTries );
        }


        public void Medium ()
        {
            int triesNumber = 7;
            int maxTries = triesNumber;
            int range = 500;
            int randomNum = new Random().Next(0, range);
            int rangeMultiplication = 5;
            Game(GameType, triesNumber, range, randomNum, rangeMultiplication, maxTries);

        }

        public void Hard()
        {
            int triesNumber = 5;
            int maxTries = triesNumber;
            int range = 1000;
            int randomNum = new Random().Next(0, range);
            int rangeMultiplication = 10;
            Game(GameType, triesNumber, range, randomNum, rangeMultiplication, maxTries);

        }



        public void Game(string gamemode, int numberOfTries, int rangeMode, int randomNumber, int rangeMultiplication, int maxTries)
        {
            bool playing = true;
            Console.WriteLine($"You have chosen {gamemode} mode. Be careful, you only have {numberOfTries} tries and the range mode is: {rangeMode}! \nNow, start entering numbers : )");

            while(playing)
            {
                string guess = Console.ReadLine();
                bool isValid = int.TryParse(guess, out int numberGuessed);
                if (!isValid || numberGuessed > rangeMode || numberGuessed < 0)
                {
                    Console.WriteLine("Invalid number");
                    continue;
                }
                else if (numberGuessed == randomNumber)
                {
                    if (numberOfTries == maxTries)
                    {
                        Console.WriteLine("Lucky guess!");
                    }
                    Console.WriteLine($"Nailed it. number entered: {numberGuessed}. You managed to do so in {maxTries - numberOfTries} tries!");
                    playing = false;

                }
                else if (numberGuessed != randomNumber && numberOfTries == 1)
                {
                    
                    Console.WriteLine($"You run out of tries :( The number was: {randomNumber}");
                    playing = false;
                    continue;
                }

                else if (numberGuessed <= (randomNumber + 3 * rangeMultiplication) && numberGuessed>randomNumber)
                {
                    
                    numberOfTries--;
                    Console.WriteLine($"Your guess is a little bit higher, try again! The number entered is:{numberGuessed}, remaining tries: {numberOfTries}");
                    continue;
                }

                else if (numberGuessed >= (randomNumber - 3 * rangeMultiplication) && numberGuessed<randomNumber)
                {
                    
                    numberOfTries--;
                    Console.WriteLine($"Your guess is a little bit lower, try again! The number entered is:{numberGuessed}, remaining tries: {numberOfTries}");
                    continue;
                }
                else if (numberGuessed < randomNumber)
                {
                    
                    numberOfTries--;
                    Console.WriteLine($"Your guess is low, try again! The number entered is:{numberGuessed}, remaining tries: {numberOfTries}");
                    continue;
                }
                else if (numberGuessed > randomNumber)
                {
                    
                    numberOfTries--;
                    Console.WriteLine($"Your guess is high, try again! The number entered is:{numberGuessed}, remaining tries: {numberOfTries}");
                    continue;
                }
            }

        }

    }
}


