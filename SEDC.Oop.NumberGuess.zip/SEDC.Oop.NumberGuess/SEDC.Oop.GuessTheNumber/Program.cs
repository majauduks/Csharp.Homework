﻿using SEDC.Oop.GuessTheNumber.Guessing;
using System;

namespace SEDC.Oop.GuessTheNumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string a = "y";
             
            while(a=="y")
            {
                Console.WriteLine("Enter which game you want to play. You can choose between: \n1.Easy \n2.Medium \n3.Hard");
                string input = Console.ReadLine();
                string inputLowerCase = input.ToLower();
                
                if(inputLowerCase != "easy" && inputLowerCase != "medium" && inputLowerCase != "hard")
                {
                    Console.WriteLine("Please, enter a valid choice!"); ;
                    continue;
                }

                else if(inputLowerCase == "easy")
                {
                    Console.WriteLine("easy mode");
                    Modes game = new Modes(inputLowerCase);
                    game.Easy();
                    

                }
                else if(inputLowerCase =="medium")
                {
                    Console.WriteLine("medium mode");
                    Modes game = new Modes(inputLowerCase);
                    game.Medium();

                }
                else if (inputLowerCase == "hard")
                {
                    Console.WriteLine("hard mode");
                    Modes game = new Modes(inputLowerCase);
                    game.Hard();
                    

                }
                Console.WriteLine("Press 'Y' to play another game, or 'N' to finish");
                string toReturn = Console.ReadLine();
                a = toReturn.ToLower();
                if (a != "y")
                {
                    Console.WriteLine("Thank you for playing this game");
                }
                continue;
            }
        }
    }
}
